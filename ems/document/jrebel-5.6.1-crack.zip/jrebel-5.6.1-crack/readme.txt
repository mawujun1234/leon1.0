The ZIP distrubution is to be used without the IDE


Activating a JRebel license
===========================

To activate a JRebel license from the command line, run:

bin/activate.{cmd|sh} <ACTIVATION_KEY_OR_PATH_TO_LICENSE_FILE>


To activate a JRebel license using a GUI activation wizard, run:

bin/activate-gui.{cmd|sh}


Enabling JRebel for your server
===============================

To enable JRebel for your server container, run:

bin/setup.{cmd|sh}

and follow the instructions displayed in the Usage.
For the simplest case (enabling JRebel for Tomcat for example), run:

bin/setup.{cmd|sh} -r "path/to/tomcat/installation/directory"
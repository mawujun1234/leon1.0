package com.mawujun.repository.cnd;




public interface SqlExpression  extends PItem{
	SqlExpression setNot(boolean not);
}

package com.mawujun.repository.cnd;

public enum SqlType {
	SELECT, DELETE, TRUNCATE, UPDATE, INSERT, CREATE, DROP, RUN, ALTER, OTHER
}
